# WT Tactical MFD

Custom War Thunder telemetry display: pan/zoom tactical map, AA threat
envelopes, weapon range overlays, and a live safety readout that answers
"can I hit this and stay clear of AA" directly instead of eyeballing
overlapping circles.

## Fast update workflow

For every update after your initial install, `update.sh` (included in
every zip) syncs a freshly-extracted copy straight into your real
install folder - no manual file copying, and it cleans up files that
were removed in the new version instead of leaving stale copies behind:

```bash
# extract the new zip anywhere, then from inside that extracted folder:
./update.sh                  # syncs to ~/Downloads/wt-mfd (the default)
./update.sh /custom/path     # or syncs to a custom location
```

Then go to `about:debugging#/runtime/this-firefox` and click **Reload**
on the extension - that part still has to be manual, browsers don't
expose a way to trigger it from a script for a temporary add-on.

This doesn't apply to your very first install - see "Load it in Firefox"
above for that one-time setup.

## Load it in Firefox (temporary, for testing)

1. `about:debugging#/runtime/this-firefox` → **Load Temporary Add-on** →
   select `manifest.json`.
2. Get into a match, click the toolbar icon to open the MFD in its own tab.
3. Drag it to a second monitor, or capture it as an OBS browser source.

If you get "Loading failed for the script" on load: on Steam Deck /
Flatpak Firefox, the folder needs to be somewhere Firefox's sandbox can
already see (e.g. `~/Downloads`) - Flatpak's file picker often doesn't
grant access to sibling files outside that.

## Confirmed API schema (from live debug logging)

War Thunder's localhost API is undocumented; these are the fields
actually observed, not assumed:

- **Coordinates**: `map_obj.json` entries use `x`/`y` as 0..1 fractions
  of the map (not raw engine units).
- **`type` is a coarse bucket** - e.g. `"ground_model"` covers ships and
  ground vehicles alike. **`icon` carries the real identity** - `"SPAA"`,
  `"SAM"`, `"LightTank"`, `"Fighter"`, `"MissileDestroyer"`, etc. Classify
  by `icon`, not `type`.
- **Player's own aircraft**: `type: "aircraft"`, `icon: "Player"` (exact
  case).
- **Team color**: `color` is a ready-to-use hex string, but `"color[]"`
  (an `[r,g,b]` int array) is far more reliable for friendly/enemy
  classification than string-matching the hex - own team measured as
  green-dominant (e.g. `[31,250,0]`); red-dominant is assumed enemy by
  convention but hasn't been directly confirmed in logs yet.
- **Airfields** report as a line segment (`sx,sy,ex,ey` or `ep1`/`ep2`),
  not a point - handled separately from point objects.
- **`map_info.json`**: `map_min`/`map_max` are a fixed `±65536` engine
  constant, *not* the real map size - don't use them for meters-per-pixel
  scaling. `grid_size` (e.g. `[52719, 55385]`) is the actual map footprint
  in meters and is what range-circle scaling uses. There's no `name`
  field in this endpoint.
- Still unverified, used with fallbacks: `radar_target_range`, `ralt`,
  `Vy, m/s`, `compass`/`compass1`/`heading`. Turn on "Debug: log new map
  object types" in the sidebar and check the console if these seem wrong
  for your client version.

## How the safety readout works

- **AA THREAT**: scans enemy-classified AA (by `color[]`, not text
  matching) and reports the closest one that has you inside its range
  band. **CAUTION** = inside the profile's scaled outer envelope (you
  might be in range, depending on which specific vehicle this generic
  icon actually is). **DANGER** = inside the profile's unscaled minimum,
  i.e. most vehicles in that category could reach you here regardless of
  altitude/speed scaling. **CLEAR** = outside both.
- **NEAREST TARGET / IN WEAPON RANGE**: finds the closest contact that's
  actually a sensible target for your selected weapon (missiles only
  match aircraft; bombs/glide bombs only match ground/naval), and
  compares its distance against your weapon's live-computed range.

## Map scale calibration

Distance math (AA rings, weapon ranges, the measurement tool) depends on
knowing the map's real-world size in meters. `map_info.json`'s
`grid_size` field is used for this, but its raw value doesn't reliably
equal true distances (confirmed by testing against an in-game lock-on
range) - the reason is unknown, so rather than hardcode a guessed
correction factor, there's an in-app **MAP SCALE CALIBRATION** panel:

1. Get a known-true distance to something - an in-game radar/gun lock
   range works well since it doesn't require an actual weapon release.
2. Right-click-drag with the measurement tool between your position and
   that same target.
3. Enter the true distance (in meters) into the panel and click **Add
   Data Point**.
4. Repeat with a few more points at different distances if you can - the
   more points, the more reliable the fit. The panel shows each point,
   the currently-active correction factor (least-squares fit across all
   points), and updates live as you add more.

This is saved **per map** (keyed by `map_generation`, since
`map_info.json` has no map name field), so a different map starts fresh
rather than inheriting a correction that might not apply to it - this is
also how we're finding out whether the correction is universal or
map-specific, which wasn't previously known.

## Known simplifications (be aware of these)

- **Map projection**: `worldToScreen`/`screenToWorld` and the map image
  draw went through two rounds of fixes for direction-dependent distance
  distortion - first, independently stretching the map's X-axis to
  `canvas.width` and Y-axis to `canvas.height` (correct only if the
  browser window's aspect ratio happened to match the map's real aspect
  ratio, which it never does); then, deriving the Y-axis scale from the
  fetched map image's raw pixel aspect ratio (also wrong, since a game's
  minimap texture has no guaranteed relationship to real-world
  proportions). Both are fixed - Y-scale now comes from `grid_size`'s
  ratio, with image aspect only as a last-resort fallback. Any
  measurement or calibration data from before both fixes should be
  treated as unreliable.

- **AA range bands are generic categories, not per-vehicle.** The API
  only reveals an enemy's category (`SPAA`, `SAM`, ...) until you've
  identified the specific vehicle, so `AA_RANGE_PROFILES` in `mfd.js`
  covers a wide band across the whole BR spread. If you mostly play a
  narrow BR range, narrowing these bands will make CAUTION/DANGER more
  precise.
- **Bomb and glide-bomb range now come from a real point-mass trajectory
  simulation** (gravity + drag, plus a glide-ratio-driven lift term for
  guided glide bombs), integrated against your aircraft's *actual* current
  velocity vector (TAS decomposed with vertical speed) rather than
  assuming a level release. This replaced the old closed-form CCIP
  fall-time fudge and the linear glide-range formula.
- **The glide-bomb footprint is drawn as a filled wedge**, not a full
  circle - its angular width comes from each weapon's
  `maneuverHalfAngleDeg` (its real off-axis maneuvering basket; 0 for a
  straight-flying munition), not one fixed angle for every glide weapon.
- **`mass`/`refArea`/`dragCoeff`/`glideRatio` are still real-world
  reference estimates for every weapon except MK 82** (see below), not
  calibrated to War Thunder's actual in-game ballistics. **Important:**
  calibrating these means matching WT's simplified bomb model, not real
  aerodynamics - the resulting `dragCoeff` values can end up far outside
  anything physically realistic (MK 82 needed ~4.0, versus ~0.2-0.3 for a
  real bomb shape) and that's expected, not a bug. `calibrateDragCoeff`'s
  search range is deliberately wide (up to 200) for this reason - don't
  narrow it back to "realistic" bounds. To calibrate a weapon: drop it at
  a known altitude and speed (the in-game CCIP reticle's indicated impact
  point works as the target range - no need to wait for an actual splash),
  measure the distance with the right-click measurement tool, then in the
  MFD's browser console run:
  ```js
  // unguided bomb - solve for dragCoeff:
  calibrateDragCoeff(COUNTRY_WEAPONS.USA["MK 82 (500lb) Bomb"], releaseAltM, vx0, vy0, observedRangeM)
  // guided glide bomb - solve for glideRatio:
  calibrateGlideRatio(COUNTRY_WEAPONS.USA["GBU-39 SDB (Glide)"], releaseAltM, vx0, vy0, observedRangeM)
  ```
  where `vx0`/`vy0` are your release velocity components (level release:
  `vx0 = speedMs`, `vy0 = 0`). Paste the returned number back into that
  weapon's entry in `COUNTRY_WEAPONS` in `mfd.js`. **One calibration point
  only pins down the curve at that one altitude/speed** - a second test at
  a notably different altitude or speed is the way to confirm (or correct)
  whether it generalizes across the envelope, since War Thunder's actual
  drag curve shape is unknown.

  **Calibration log:**
  - `MK 84 (2000lb) Bomb`: `dragCoeff: 0.117`, calibrated from a
    level-flight drop at 1277m altitude, vx0=237/vy0=1 m/s -> 3.71km
    in-game CCIP, measured with a properly map-scale-calibrated ruler.
    Notably, this value is physically plausible for a real bomb shape
    (~0.15-0.4 typical range) - unlike the earlier `4.75`, which was
    always a "whatever matches the game" fudge with no physical grounding.
    Cross-checking confirms the two readings are incompatible with each
    other (0.117 predicts ~4.27km for the old test's conditions, nowhere
    near its claimed 1.66km) - strong evidence the earlier ruler really
    was under-measuring distances before per-map calibration existed,
    rather than this being a case of two valid-but-different results.
    Still just one trustworthy data point, and the map it was measured on
    had a wide scale-calibration spread (2.4x-4.0x) at the time - a second
    reading (ideally after tightening that spread) would help confirm
    this before fully trusting it. `MK 82` and `MK 83` are still untested
    placeholders.
- Team classification's enemy side (red-dominant RGB) is inferred by
  convention, not yet confirmed against a logged enemy object - if AA
  threat detection seems to miss actual enemies, check the debug log for
  what an enemy's `color[]` actually looks like and adjust `classifyTeam`
  in `mfd.js` if needed.

## Persisted settings

Selected country/weapon and the overlay checkboxes (AA rings, friendly
AA, weapon FOV, bomb CCIP, dynamic scaling, grid, airfields) are saved to
`localStorage` and restored on reopen. Compact/Deck layout is also
persisted. The debug logger checkbox is intentionally not persisted -
it's off by default every time to avoid console spam.

## Compact / Deck / phone layout

Check "Compact Layout (Deck / phone)" at the bottom of the sidebar. The
sidebar becomes an off-canvas drawer (opened via the ☰ button, always
visible in this mode) with larger touch targets, instead of permanently
taking up screen width. Useful when you drag the window to a smaller or
touch screen.
