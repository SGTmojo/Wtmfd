#!/usr/bin/env python3
"""
Virtual joystick feasibility test #3 (remote-controlled version)
====================================================================
Same purpose as before (confirm joystick-class buttons avoid the Guide-
button/Steam-hijacking problem, and check whether more than 3 buttons can
register), but controlled from your PHONE instead of pressing Enter on
the Deck's own keyboard - pressing Enter in a terminal means clicking
into Konsole first, which takes focus away from War Thunder and defeats
the whole point of the test. This way the Deck's focus never has to
leave the game.

USAGE:
    python3 gamepad_test3.py [port]
    (default port: 8090 - different from serve.py's default 8080, so you
    can run both at once without a collision if you want to)

Then on your phone (same WiFi as this Deck), open the URL this prints -
you'll see a big "SEND NEXT BUTTON" button. Each tap:
  1. Sends the next button in the sequence (A, B, X, Y, LB, RB, SELECT,
     START, MODE, L3, R3, in that order).
  2. Shows you which one it just sent.

For each one: click to add a new binding for "Target Camera (Helicopter)"
in WT's Controls settings FIRST, then tap the phone button - keeps the
Deck's focus on the game the entire time.

Watch for:
  - Does anything open Steam? (specifically around button 9, "MODE")
  - Do you get past 3 buttons registering?

Press Ctrl+C on the Deck to stop.
"""
import http.server
import socket
import sys
import time

try:
    from evdev import UInput, ecodes as e
except ImportError:
    print("Missing dependency. Run this first:")
    print("    python3 -m pip install evdev --break-system-packages")
    raise SystemExit(1)

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8090

BUTTON_NAMES = ["A", "B", "X", "Y", "LB", "RB", "SELECT", "START", "MODE", "L3", "R3"]
JOYSTICK_CODES = [
    e.BTN_TRIGGER, e.BTN_THUMB, e.BTN_THUMB2, e.BTN_TOP,
    e.BTN_TOP2, e.BTN_PINKIE, e.BTN_BASE, e.BTN_BASE2,
    e.BTN_BASE3, e.BTN_BASE4, e.BTN_BASE5,
]
CAPABILITIES = {
    e.EV_KEY: JOYSTICK_CODES,
    e.EV_ABS: [
        (e.ABS_X, (0, -32768, 32767, 0, 0)),
        (e.ABS_Y, (0, -32768, 32767, 0, 0)),
        (e.ABS_RX, (0, -32768, 32767, 0, 0)),
        (e.ABS_RY, (0, -32768, 32767, 0, 0)),
        (e.ABS_Z, (0, 0, 255, 0, 0)),
        (e.ABS_RZ, (0, 0, 255, 0, 0)),
    ],
}

print("Creating virtual joystick (joystick-class buttons, no Guide button concept)...")
device = UInput(CAPABILITIES, name="WT MFD Virtual Joystick")
print("Created.")

# Mutable index tracking which button is "next" - a plain global is fine
# here since this is a single-purpose diagnostic script, not the real
# multi-threaded server.
next_index = [0]


def send_next_button():
    if next_index[0] >= len(BUTTON_NAMES):
        return None, "All 11 buttons already sent - restart the script to go again."
    name = BUTTON_NAMES[next_index[0]]
    code = JOYSTICK_CODES[next_index[0]]
    device.write(e.EV_KEY, code, 1)
    device.syn()
    time.sleep(0.1)
    device.write(e.EV_KEY, code, 0)
    device.syn()
    next_index[0] += 1
    remaining = len(BUTTON_NAMES) - next_index[0]
    return name, f"Sent '{name}'. {remaining} button(s) left."


PAGE_TEMPLATE = """<!DOCTYPE html>
<html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Joystick Test</title>
<style>
body {{ background:#0a0e17; color:#fff; font-family:monospace; text-align:center; padding:20px; }}
button {{ font-size:24px; padding:30px 20px; width:100%; background:#131c31; color:#00ffcc;
          border:2px solid #2e4470; border-radius:10px; margin-top:20px; }}
button:active {{ background:#00ffcc; color:#05070a; }}
#status {{ font-size:16px; margin-top:20px; color:#8b9bb4; }}
</style></head>
<body>
<h2>Virtual Joystick Test</h2>
<div id="status">{status}</div>
<button onclick="sendNext()">SEND NEXT BUTTON</button>
<script>
async function sendNext() {{
    const res = await fetch('/next', {{ method: 'POST' }});
    const text = await res.text();
    document.getElementById('status').textContent = text;
}}
</script>
</body></html>"""


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = PAGE_TEMPLATE.format(status="Ready. Tap the button below to send button 1 (A).").encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path == "/next":
            name, message = send_next_button()
            print(f"  -> {message}")
            body = message.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        pass  # quiet - the print() in send_next_button already shows progress


def get_lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "<couldn't detect - run 'hostname -I' manually>"
    finally:
        s.close()


if __name__ == "__main__":
    lan_ip = get_lan_ip()
    print()
    print("On your phone (same WiFi as this Deck), open:")
    print(f"    http://{lan_ip}:{PORT}/")
    print()
    print("Tap the button there once per binding - keeps this Deck's focus on")
    print("War Thunder the whole time. Press Ctrl+C here to stop.")
    server = http.server.ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        device.close()
