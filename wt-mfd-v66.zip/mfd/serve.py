#!/usr/bin/env python3
"""
WT Tactical MFD - local server for phone/tablet access
========================================================
Serves this tool's files AND proxies War Thunder's telemetry API, so a
phone on the same WiFi network can open the tool in ANY browser - no
Firefox extension installation needed, which isn't realistically possible
on mobile anyway.

WHY A PROXY, not just pointing the phone straight at localhost:8111?
  1. "localhost" on a phone means the PHONE itself, not this Deck - the
     phone needs this machine's real LAN IP either way.
  2. Browsers enforce CORS (Cross-Origin Resource Sharing) for plain
     webpages in a way they don't for installed browser extensions (the
     Firefox extension bypasses this via its declared host_permissions -
     a plain webpage gets no such exemption). Rather than gamble on
     whether War Thunder's API sends the right CORS headers for a
     cross-origin browser fetch, the phone only ever talks to ONE origin
     (this server), and THIS server - running ON the Deck - reaches the
     game via genuine localhost, which is guaranteed to work since that's
     exactly how the Firefox extension already does it successfully.

USAGE:
    python3 serve.py [port]
    (default port: 8080)

Then on your phone (same WiFi network as this Deck), open:
    http://<this Deck's LAN IP>:8080/mfd.html

Find this Deck's LAN IP by running `hostname -I` in another terminal, or
just watch this script's own startup banner - it prints its best guess.
"""
import functools
import http.server
import json
import os
import re
import socket
import sys
import threading
import time
import urllib.error
import urllib.request

# Virtual gamepad support is OPTIONAL - if the evdev package isn't
# installed, or /dev/uinput isn't accessible, the rest of this server
# (serving files, proxying telemetry) still works fine; only the gamepad
# button endpoints become unavailable. Never let a missing optional
# feature take down the whole server.
try:
    from evdev import UInput, ecodes as ec
    EVDEV_AVAILABLE = True
except ImportError:
    EVDEV_AVAILABLE = False

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
WT_API_BASE = "http://localhost:8111"
# Paths that are War Thunder's live telemetry (proxied through to the
# actual game) rather than this tool's own static files.
PROXIED_PREFIXES = ("/state", "/indicators", "/map_obj.json", "/map_info.json", "/map.img")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================================
# Virtual gamepad - lets the web UI's buttons press a real (virtual)
# joystick/gamepad button, which you then bind to whatever in-game action
# you want via War Thunder's own Controls settings (Gear, Flaps, etc.) -
# same convenience as an extra macro pad, not automation: nothing here
# decides WHEN to press anything, it only presses what a person taps
# on-screen.
#
# HISTORY (four iterations to get here, each confirmed/refuted by real
# testing, not assumption):
#   1. Virtual GAMEPAD spoofing a real Xbox 360 controller's exact
#      vendor/product ID, for max compatibility - collided with an
#      actual physical controller and stopped it connecting.
#   2. Virtual KEYBOARD to avoid that collision - worked in War Thunder's
#      Controls BINDING menu, but never actually registered during real
#      gameplay. Likely cause: Wine's DirectInput keyboard reading is a
#      separate code path from normal windowing key events.
#   3. Back to a virtual GAMEPAD with a generic, non-spoofed identity -
#      fixed the controller collision, but BTN_MODE (the "Guide/Home"
#      button convention) got intercepted by Steam Input globally,
#      opening Steam instead of reaching the game.
#   4. Switched to the BTN_TRIGGER_HAPPY1-40 code range (0x2c0-0x2e7) -
#      sits outside both the DirectInput gamepad range (BTN_GAMEPAD/
#      BTN_MODE, which Proton's winebus and Steam Input treat specially)
#      and the low BTN_BASE joystick range. Explicit non-zero vendor/
#      product ID so SDL2 enumerates it as a real controller. Confirmed
#      via direct testing: all 20 buttons bind correctly, nothing opens
#      Steam at any point in the sequence.
#
# 20 buttons (not 11) - enough for the Controls page's 4-page x 5-button
# layout (Flight / Weapons / Radar / In-Game MFD) without reusing the same
# handful of outputs across different logical pages.
# ============================================================================
GAMEPAD_CAPABILITIES = {}
GAMEPAD_BUTTONS = {}  # name (used in the URL, "H1".."H20") -> evdev button code
# The plain list of button names, independent of whether evdev/uinput is
# actually available - the .blk calibration/sync logic below is pure text
# processing and has nothing to do with the live virtual device, so it
# shouldn't be unable to function just because evdev happens to be missing.
GAMEPAD_BUTTON_CODES = [f"H{i}" for i in range(1, 21)]
gamepad_device = None
gamepad_lock = threading.Lock()

if EVDEV_AVAILABLE:
    # Falls back to raw numeric codes if a particular evdev version doesn't
    # expose every BTN_TRIGGER_HAPPY name as a constant (some older
    # versions only define a subset by name) - matches gamepad_test4.py.
    GAMEPAD_BUTTONS = {}
    for i in range(1, 21):
        const_name = f"BTN_TRIGGER_HAPPY{i}"
        GAMEPAD_BUTTONS[f"H{i}"] = getattr(ec, const_name, 0x2c0 + (i - 1))

    GAMEPAD_CAPABILITIES = {
        ec.EV_KEY: list(GAMEPAD_BUTTONS.values()),
        ec.EV_ABS: [
            (ec.ABS_X, (0, -32768, 32767, 0, 0)),
            (ec.ABS_Y, (0, -32768, 32767, 0, 0)),
        ],
    }


def press_gamepad_button(name):
    """Presses and releases one virtual gamepad button. Returns (ok, message)."""
    if gamepad_device is None:
        return False, "Virtual gamepad not available (evdev missing, or failed to create - see startup log)"
    code = GAMEPAD_BUTTONS.get(name)
    if code is None:
        return False, f"Unknown button '{name}'. Valid: {', '.join(GAMEPAD_BUTTONS.keys())}"
    # Locked so two near-simultaneous requests (e.g. someone double-tapping)
    # can't interleave their press/release event pairs on the same device.
    # ~20ms hold - matches gamepad_test4.py exactly, confirmed working
    # end-to-end (all 20 buttons bound, nothing opened Steam) - shorter
    # than the earlier 100ms figure since a different button-code range
    # can behave differently, and this specific value is what was tested.
    with gamepad_lock:
        gamepad_device.write(ec.EV_KEY, code, 1)
        gamepad_device.syn()
        time.sleep(0.02)
        gamepad_device.write(ec.EV_KEY, code, 0)
        gamepad_device.syn()
    return True, f"Pressed {name}"


# ============================================================================
# .blk controls-file calibration & sync
# ----------------------------------------------------------------------------
# War Thunder assigns our virtual gamepad's buttons a GLOBAL button number
# (deviceOffset + local button index) that's stable WITHIN one continuous
# session, but can shift to a different offset after War Thunder or this
# server restarts (confirmed directly against a real exported controls.blk -
# two exports minutes apart, nothing else changed except a restart, showed
# "pad 1" and "pad 2" swapping their offset ranges). So instead of trying to
# predict the offset, this reads it fresh from a real bind each time:
#
#   PHASE 1 (once, or whenever the local-button layout itself might have
#   changed - it normally won't): bind ALL 11 of our buttons, in order, to
#   one harmless unused action, without clearing between presses (WT stacks
#   repeated binds onto the same action rather than overwriting - confirmed
#   from a real export). Upload that file once - this computes each
#   button's position RELATIVE to the first one (a fixed, device-intrinsic
#   spacing that doesn't depend on the current offset) and saves it.
#
#   PHASE 2 (any time after a restart, ~10 seconds): bind just ONE button
#   (button "A") to that same throwaway action, upload the person's real,
#   current controls.blk (which now also contains that one fresh bind).
#   That single value anchors the current session's offset; combined with
#   the saved relative spacing from Phase 1, every other button's CURRENT
#   global number can be computed without touching deviceMapping or device
#   names at all - sidesteps the whole "which named device is ours"
#   ambiguity entirely, since everything is inferred from real, freshly-
#   observed bind values.
#
# Every operation here works on a COPY of the uploaded text and returns a
# NEW file - nothing is ever written back to the person's live game folder
# automatically. They review and re-import it themselves.
# ============================================================================
CALIBRATION_FILE = os.path.join(SCRIPT_DIR, "gamepad_calibration.json")
# A real, currently-unbound (in the sample file this was built against),
# harmless action - used purely as a place to stack throwaway calibration
# binds. If this happens to be bound to something you use, change it here.
CALIBRATION_ACTION_ID = "ID_TARGET_CAMERA_HELICOPTER"

# Button -> WT action ID. Only entries confirmed to actually exist (by
# directly inspecting a real exported controls.blk) are filled in here -
# guessing at an action ID and silently writing a wrong one into someone's
# real bindings file is a real risk, not a hypothetical one, so the rest
# are deliberately left blank until confirmed. Editable via the UI (stored
# in CALIBRATION_FILE, these are just the fallback defaults).
# Grouped to match the Controls page's 4 pages x 5 buttons layout.
DEFAULT_TARGET_IDS = {
    # FLIGHT (H1-H5)
    "H1": "ID_GEAR",       # confirmed - already actively bound in a real export
    "H2": "ID_FLAPS",      # confirmed - already actively bound
    "H3": "ID_AIR_BRAKE",  # confirmed - already actively bound
    "H4": "",              # not confirmed
    "H5": "",              # not confirmed
    # WEAPONS (H6-H10)
    "H6": "",              # FIRE - not confirmed
    "H7": "ID_BOMBS",      # confirmed to exist, currently unbound
    "H8": "ID_LOCK_TARGETING",  # confirmed - already actively bound
    "H9": "",              # not confirmed
    "H10": "",             # not confirmed
    # RADAR (H11-H15) - no clear simple toggles found, all user-configurable
    "H11": "", "H12": "", "H13": "", "H14": "", "H15": "",
    # IN-GAME MFD (H16-H20) - not confirmed, all user-configurable
    "H16": "", "H17": "", "H18": "", "H19": "", "H20": "",
}


def load_calibration():
    if os.path.exists(CALIBRATION_FILE):
        with open(CALIBRATION_FILE) as f:
            return json.load(f)
    return {"deltas": None, "target_ids": dict(DEFAULT_TARGET_IDS)}


def save_calibration(data):
    with open(CALIBRATION_FILE, "w") as f:
        json.dump(data, f, indent=2)


def extract_joybutton_values(blk_text, action_id):
    """
    Returns every joyButton:i=N value found inside ANY block(s) named
    exactly `action_id{ ... }`, in file order. WT allows the same action ID
    to appear as several separate blocks rather than overwriting (confirmed
    from a real export - repeated binds stack up), so this scans the WHOLE
    file rather than stopping at the first match.

    Uses a simple brace-depth line scanner rather than a full grammar
    parser - sufficient because hotkey entries in this format are always a
    single level deep (name{ key:type=value ... }, no nesting inside),
    confirmed directly from a real exported file.
    """
    values = []
    lines = blk_text.splitlines()
    in_block = False
    depth = 0
    open_marker = f"{action_id}{{"
    for line in lines:
        stripped = line.strip()
        if not in_block:
            if stripped.startswith(open_marker):
                # BUG FIX (caught by testing against a real file): a
                # single-line empty block like "ID_X{}" has its closing
                # brace on the SAME line as the opening one. The old code
                # unconditionally set depth=1 and moved to the next line
                # without ever looking at this line's own closing brace -
                # so it stayed "in_block" forever, silently vacuuming up
                # joyButton values from every unrelated block after it.
                # Counting THIS line's own braces fixes it.
                depth = stripped.count("{") - stripped.count("}")
                if depth > 0:
                    in_block = True
            continue
        depth += stripped.count("{")
        depth -= stripped.count("}")
        m = re.match(r"joyButton:i=(-?\d+)", stripped)
        if m:
            values.append(int(m.group(1)))
        if depth <= 0:
            in_block = False
    return values


def strip_action_blocks(blk_text, action_id):
    """Removes every block named `action_id{ ... }` entirely - used to
    clean out the throwaway calibration binds before returning the final
    file, so they don't clutter the person's real controls."""
    lines = blk_text.splitlines()
    result = []
    i = 0
    open_marker = f"{action_id}{{"
    while i < len(lines):
        stripped = lines[i].strip()
        if stripped.startswith(open_marker):
            # Same fix as extract_joybutton_values above - must count this
            # opening line's OWN braces first. Getting this wrong here is
            # more dangerous than in the read-only extractor above, since
            # this function DELETES lines - the old bug could have silently
            # deleted real, unrelated bindings it mistakenly thought were
            # still "inside" an already-closed single-line block.
            depth = stripped.count("{") - stripped.count("}")
            i += 1
            while i < len(lines) and depth > 0:
                depth += lines[i].count("{")
                depth -= lines[i].count("}")
                i += 1
            if i < len(lines) and lines[i].strip() == "":
                i += 1  # also swallow one trailing blank line, avoids a double gap
            continue
        result.append(lines[i])
        i += 1
    return "\r\n".join(result) + "\r\n"


def insert_hotkey_bindings(blk_text, bindings):
    """
    bindings: { action_id: [global joyButton numbers] }. Appends a NEW
    ID_XXX{ joyButton:i=N ... } block per entry, right before the closing
    brace of the hotkeys{ } section - every existing line is left
    completely untouched, this only ADDS blocks.
    """
    lines = blk_text.splitlines()
    hotkeys_start = None
    for i, line in enumerate(lines):
        if line.strip() == "hotkeys{":
            hotkeys_start = i
            break
    if hotkeys_start is None:
        raise ValueError("Could not find a hotkeys{ block in the uploaded file - is this a real exported controls.blk?")

    depth = 1
    insert_at = None
    for i in range(hotkeys_start + 1, len(lines)):
        depth += lines[i].count("{")
        depth -= lines[i].count("}")
        if depth == 0:
            insert_at = i
            break
    if insert_at is None:
        raise ValueError("Could not find the end of the hotkeys{ block - the file may be truncated or malformed")

    new_lines = []
    for action_id, joy_buttons in bindings.items():
        if not action_id:
            continue
        new_lines.append(f"    {action_id}{{")
        for jb in joy_buttons:
            new_lines.append(f"      joyButton:i={jb}")
        new_lines.append("    }")
        new_lines.append("")

    return "\r\n".join(lines[:insert_at] + new_lines + lines[insert_at:]) + "\r\n"


def run_phase1_calibration(blk_text):
    """Computes each button's fixed position relative to button 'A', from
    a file where all 11 buttons were bound (in GAMEPAD_BUTTON_CODES order)
    to CALIBRATION_ACTION_ID without clearing between presses."""
    codes = GAMEPAD_BUTTON_CODES
    values = extract_joybutton_values(blk_text, CALIBRATION_ACTION_ID)
    if len(values) != len(codes):
        return False, f"Expected {len(codes)} joyButton values under {CALIBRATION_ACTION_ID}, found {len(values)}. Make sure all {len(codes)} buttons were bound in order ({', '.join(codes)}) without clearing between presses, then re-export."
    anchor = values[0]  # "A"
    deltas = {code: values[i] - anchor for i, code in enumerate(codes)}
    data = load_calibration()
    data["deltas"] = deltas
    save_calibration(data)
    return True, f"Calibration saved. Relative spacing: {deltas}"


def run_phase2_sync(blk_text):
    """Uses one fresh 'A' bind (already present in the uploaded full file)
    plus the saved Phase 1 spacing to compute every button's CURRENT
    global number, appends the real bindings, strips the throwaway
    calibration entry, and returns the finished file text."""
    data = load_calibration()
    if not data.get("deltas"):
        return False, None, "No Phase 1 calibration saved yet - run that first."

    values = extract_joybutton_values(blk_text, CALIBRATION_ACTION_ID)
    if len(values) != 1:
        return False, None, f"Expected exactly 1 fresh joyButton value under {CALIBRATION_ACTION_ID} (bind button A once, nothing else, then export), found {len(values)}."
    anchor = values[0]

    deltas = data["deltas"]
    target_ids = data.get("target_ids", DEFAULT_TARGET_IDS)
    bindings = {}
    skipped = []
    for code, delta in deltas.items():
        target_id = target_ids.get(code, "")
        if not target_id:
            skipped.append(code)
            continue
        bindings[target_id] = [anchor + delta]

    try:
        result = insert_hotkey_bindings(blk_text, bindings)
        result = strip_action_blocks(result, CALIBRATION_ACTION_ID)
    except ValueError as e:
        return False, None, str(e)

    msg = f"Added {len(bindings)} binding(s): {', '.join(bindings.keys())}."
    if skipped:
        msg += f" Skipped (no target ID set yet): {', '.join(skipped)}."
    return True, result, msg


class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith(PROXIED_PREFIXES):
            self.proxy_to_war_thunder()
        elif self.path.startswith("/gamepad/press/"):
            self.handle_gamepad_press()
        elif self.path == "/blk/status":
            self.handle_blk_status()
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == "/blk/calibrate":
            self.handle_blk_calibrate()
        elif self.path == "/blk/sync":
            self.handle_blk_sync()
        elif self.path == "/blk/target_ids":
            self.handle_blk_target_ids()
        else:
            self.send_response(404)
            self.end_headers()

    def do_HEAD(self):
        # mfd.js only ever uses fetch() (GET), so this path is never hit
        # by the actual tool - fixed anyway so manual testing (curl -I,
        # browser dev tools, etc.) doesn't see a misleading 404 here.
        if self.path.startswith(PROXIED_PREFIXES):
            self.proxy_to_war_thunder()
        else:
            super().do_HEAD()

    def read_body_text(self):
        length = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(length).decode("utf-8", errors="replace")

    def send_json(self, status, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def handle_blk_status(self):
        data = load_calibration()
        self.send_json(200, {
            "calibrated": bool(data.get("deltas")),
            "target_ids": data.get("target_ids", DEFAULT_TARGET_IDS),
            "button_codes": GAMEPAD_BUTTON_CODES,
            "calibration_action_id": CALIBRATION_ACTION_ID,
        })

    def handle_blk_calibrate(self):
        try:
            text = self.read_body_text()
            ok, msg = run_phase1_calibration(text)
            self.send_json(200 if ok else 400, {"ok": ok, "message": msg})
        except Exception as e:
            self.send_json(500, {"ok": False, "message": f"Server error: {e}"})

    def handle_blk_sync(self):
        try:
            text = self.read_body_text()
            ok, result_text, msg = run_phase2_sync(text)
            if not ok:
                self.send_json(400, {"ok": False, "message": msg})
                return
            body = result_text.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", 'attachment; filename="controls_amended.blk"')
            self.send_header("X-Sync-Message", msg)  # small status note the UI can read alongside the file
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            self.send_json(500, {"ok": False, "message": f"Server error: {e}"})

    def handle_blk_target_ids(self):
        try:
            new_ids = json.loads(self.read_body_text())
            data = load_calibration()
            target_ids = data.get("target_ids", dict(DEFAULT_TARGET_IDS))
            for code in GAMEPAD_BUTTON_CODES:
                if code in new_ids:
                    target_ids[code] = new_ids[code].strip()
            data["target_ids"] = target_ids
            save_calibration(data)
            self.send_json(200, {"ok": True, "target_ids": target_ids})
        except Exception as e:
            self.send_json(500, {"ok": False, "message": f"Server error: {e}"})

    def handle_gamepad_press(self):
        button_name = self.path.rsplit("/", 1)[-1].upper()
        ok, message = press_gamepad_button(button_name)
        body = message.encode("utf-8")
        self.send_response(200 if ok else 400)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def proxy_to_war_thunder(self):
        url = f"{WT_API_BASE}{self.path}"
        try:
            with urllib.request.urlopen(url, timeout=2) as resp:
                body = resp.read()
                self.send_response(200)
                self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json"))
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()  # adds Access-Control-Allow-Origin, see override below
                self.wfile.write(body)
        except (urllib.error.URLError, socket.timeout, ConnectionRefusedError):
            # War Thunder isn't running, or isn't in a match yet - a
            # normal/expected state (the tool's own "OFFLINE" status
            # handling already deals with this), not a real server error.
            self.send_response(503)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"War Thunder API not reachable (game not running or not in a match)")

    def end_headers(self):
        # Applied to EVERY response (static files AND proxied telemetry)
        # from one place, so it's never accidentally sent twice (duplicate
        # CORS headers can make browsers reject the response outright) and
        # never accidentally missed on some code path.
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()

    def log_message(self, format, *args):
        print(f"[serve.py] {self.address_string()} - {format % args}")


def get_lan_ip():
    """Best-effort guess at this machine's LAN IP, for the startup banner."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))  # doesn't actually send anything, just picks a route
        return s.getsockname()[0]
    except OSError:
        return "<couldn't detect - run 'hostname -I' manually>"
    finally:
        s.close()


if __name__ == "__main__":
    lan_ip = get_lan_ip()

    # Create the virtual gamepad ONCE, before the server starts, and reuse
    # the same device object for every button-press request for as long as
    # this process runs (creating a new virtual device per request would
    # make the OS see it disappear/reappear constantly, which isn't how a
    # real controller behaves). Generic identity - no vendor/product
    # spoofing - confirmed via gamepad_test2.py to avoid the collision
    # that broke a real physical controller with the original approach.
    gamepad_status = "not available (evdev not installed)"
    if EVDEV_AVAILABLE:
        try:
            gamepad_device = UInput(GAMEPAD_CAPABILITIES, name="WT MFD Virtual Joystick", vendor=0x1234, product=0x5678)
            gamepad_status = "ready"
        except Exception as e:
            gamepad_status = f"FAILED to create ({e}) - check /dev/uinput permissions"

    # directory=SCRIPT_DIR makes it serve mfd.html/mfd.js/mfd.css/etc from
    # THIS script's own folder regardless of the working directory it's
    # launched from. Binding to 0.0.0.0 (not just localhost/127.0.0.1) is
    # what actually makes it reachable from another device at all.
    handler = functools.partial(Handler, directory=SCRIPT_DIR)
    # ThreadingHTTPServer, not plain HTTPServer - the plain version handles
    # ONE request at a time, strictly in sequence. mfd.js fires off several
    # telemetry requests every 250-1000ms the moment it loads - on a
    # single-threaded server, if even one of those is slow (or War Thunder
    # isn't responding yet), it blocks EVERY other pending request behind
    # it, including the request for mfd.html/mfd.css/mfd.js themselves -
    # this is exactly what "the page just loads forever" looks like from
    # the browser's side. ThreadingHTTPServer handles each request on its
    # own thread instead, so a slow/stuck one can't stall everything else.
    #
    # BUG FIX: the startup banner (including the "open this URL on your
    # phone" line) used to print BEFORE attempting to bind the socket -
    # so if binding failed (e.g. a leftover process from a previous run
    # still holding the port), it still confidently printed a URL that
    # was never actually live, which is exactly what caused confusion
    # here: the banner looked successful even on a run that crashed
    # immediately after. Now it only prints once binding has genuinely
    # succeeded.
    #
    # AUTO PORT SWITCHING: rather than failing outright with "Address
    # already in use" (which kept happening from leftover processes from
    # earlier runs), try the next port automatically. actual_port may
    # differ from the requested PORT - the banner below always reports
    # whichever one actually worked, since that's the one that matters.
    MAX_PORT_ATTEMPTS = 20
    server = None
    actual_port = PORT
    last_error = None
    for attempt in range(MAX_PORT_ATTEMPTS):
        candidate_port = PORT + attempt
        try:
            server = http.server.ThreadingHTTPServer(("0.0.0.0", candidate_port), handler)
            actual_port = candidate_port
            break
        except OSError as e:
            last_error = e
            continue

    if server is None:
        print(f"FAILED to start: tried ports {PORT}-{PORT + MAX_PORT_ATTEMPTS - 1}, all in use.")
        print(f"Last error: {last_error}")
        print()
        print("This usually means several previous copies of this script are")
        print("still running. Try: pkill -9 -f serve.py")
        sys.exit(1)

    print("=" * 60)
    print("WT Tactical MFD - phone/tablet server")
    print("=" * 60)
    if actual_port != PORT:
        print(f"NOTE: port {PORT} was already in use - automatically switched to {actual_port} instead.")
    print(f"Serving files from:  {SCRIPT_DIR}")
    print(f"Proxying telemetry from:  {WT_API_BASE}")
    print(f"Virtual gamepad:  {gamepad_status}")
    print()
    print("On your phone (same WiFi network as this Deck), open:")
    print(f"    http://{lan_ip}:{actual_port}/mfd.html")
    print()
    print("Press Ctrl+C to stop.")
    print("=" * 60)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        if gamepad_device is not None:
            gamepad_device.close()
